# RGBspot
 Мощный RGB светильник на ATmega328
